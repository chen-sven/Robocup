#include "config.h"

// ������Թ��ܣ����������ࡶ���տ��֡���

int main()
{
	Robot_Init();
	check_music();
	while(1)
	{
		update_SWStatus();
		switch(mode)
		{
			case 0:	LED_RGB_SET(0,0,0);
							break;
			case 1:	LED_RGB_SET(100,0,0);
							break;
			case 2:	LED_RGB_SET(0,100,0);
							break;
			case 3:	LED_RGB_SET(0,0,100);
							break;
			case 4:	LED_RGB_SET(100,100,0);
							break;
			case 5:	LED_RGB_SET(0,100,100);
							break;
			case 6:	LED_RGB_SET(100,0,100);
							break;
			case 7:	LED_RGB_SET(255,255,255);
							break;
			default:	LED_RGB_SET(0,0,0);
								break;
		}
		switch(num)
		{
			case 1:	car_move(10,10,-10,-10);
							dribbler_set(0);
							break;
			case 2:	car_move(-10,-10,10,10);
							dribbler_set(0);
							break;
			case 3:	car_move(-10,-10,-10,-10);
							dribbler_set(10);
							break;
			case 4:	car_move(10,10,10,10);
							dribbler_set(10);
							break;
			default:	car_move(0,0,0,0);
								dribbler_set(0);
								break;
		}
	}
}
