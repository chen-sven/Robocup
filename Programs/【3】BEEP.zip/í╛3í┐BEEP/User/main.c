#include "config.h"

// ������Թ��ܣ����������ࡶ���տ��֡���

int main()
{
	Robot_Init();
	check_music();
	while(1)
	{
		update_SWStatus();
		switch(mode)
		{
			case 0:	LED_RGB_SET(0,0,0);
							break;
			case 1:	LED_RGB_SET(100,0,0);
							break;
			case 2:	LED_RGB_SET(0,100,0);
							break;
			case 3:	LED_RGB_SET(0,0,100);
							break;
			case 4:	LED_RGB_SET(100,100,0);
							break;
			case 5:	LED_RGB_SET(0,100,100);
							break;
			case 6:	LED_RGB_SET(100,0,100);
							break;
			case 7:	LED_RGB_SET(255,255,255);
							break;
			default:	LED_RGB_SET(0,0,0);
								break;
		}
	}
}
