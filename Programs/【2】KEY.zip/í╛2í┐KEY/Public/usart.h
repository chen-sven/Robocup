#ifndef _USART_H
#define _USART_H

#include "config.h"
#include "stdio.h"

void USART1_Init(u32 bound);

#endif
