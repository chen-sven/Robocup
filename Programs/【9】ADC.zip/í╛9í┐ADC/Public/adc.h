#ifndef _adc_H
#define _adc_H

#include "config.h"

void ADC1_Init(void);
u16 Get_ADC1_Value(u8 ch);


#endif
