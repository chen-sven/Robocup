#ifndef _MEMORY_H
#define _MEMORY_H

#include "config.h"

#define	Voltage_ADC_Init()	ADCx_Init()

#endif
