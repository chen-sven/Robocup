#ifndef	_CONFIG_H
#define _CONFIG_H

/*******************************************************************************
*                                �����ļ�������
*******************************************************************************/
#include "stm32f4xx.h"
#include "sbit.h"
#include "systick.h"
#include "usart.h"
#include "iic.h"
#include "spi.h"
#include "flash.h"
#include "adc.h"
#include "iwdg.h"
/*******************************************************************************
*                                ����Ӧ��������
*******************************************************************************/
#include "led.h"
#include "switch.h"
#include "beep.h"
#include "motor.h"
#include "encoder.h"
#include "mpu6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "nrf24l01.h"
#include "memory.h"
#include "voltage.h"
#include "shooter.h"
/*******************************************************************************
*                                ȫ�ֺ���������
*******************************************************************************/

void Robot_Init(void);

#endif
