#include "config.h"

int main()
{
	Robot_Init();
	while(1)
	{
		LED_RGB_SET(0,0,100);
		delay_ms(500);
		LED_RGB_SET(0,0,0);
		delay_ms(500);
		LED_RGB_SET(0,100,0);
		delay_ms(500);
		LED_RGB_SET(0,0,0);
		delay_ms(500);
		LED_RGB_SET(100,0,0);
		delay_ms(500);
		LED_RGB_SET(0,0,0);
		delay_ms(500);
	}
}
